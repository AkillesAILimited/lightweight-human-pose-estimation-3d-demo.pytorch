.. raw:: html

    <h2>Got questions?</h2>

We're always happy to help with code or other questions you might have.

.. raw:: html

     <div class="cta-row cta-row-short">
         <div class="cta-box">
            <a href="https://discord.gg/EPsZHkg9Nx">
               <img src="https://docs.luxonis.com/en/latest/_images/discord.png" alt="Discord"/>
               <h5 class="cta-title">Community Discord</h5>
            </a>
         </div>
         <div class="cta-box">
            <a href="https://discuss.luxonis.com/">
               <img src="https://docs.luxonis.com/en/latest/_images/forum.png" alt="forum"/>
               <h5 class="cta-title">Discussion Forum</h5>
            </a>
         </div>
         <div class="cta-box">
            <a href="mailto:support@luxonis.com">
               <img src="https://docs.luxonis.com/en/latest/_images/email.png" alt="forum"/>
               <h5 class="cta-title">Email Support</h5>
            </a>
         </div>
      </div>