def onNewFrame(frame, source):
    pass


def onShowFrame(frame, source):
    pass


def onNn(nn_packet):
    pass


def onReport(report):
    pass


def onSetup(**kwargs):
    pass


def onTeardown(**kwargs):
    pass


def onIter(**kwargs):
    pass
